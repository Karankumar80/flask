from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

app = Flask(__name__)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///quiz.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your-secret-key'

# Initialize SQLAlchemy
db = SQLAlchemy(app)

# Import routes after db initialization to avoid circular imports
from controllers.file1 import *
from controllers.file2 import *

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)